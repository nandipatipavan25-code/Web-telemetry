// Centralized API and Socket configuration for both local dev and production (VPS / Nginx)

const getBackendHost = () => {
  const envUrl = import.meta.env.VITE_API_URL || '';
  if (envUrl && envUrl.trim()) {
    // Strip trailing /api and trailing slashes if present
    return envUrl.trim().replace(/\/api\/?$/i, '').replace(/\/+$/, '');
  }

  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    // Local dev or production VPS with Nginx reverse proxy (gawebtelemetry.com)
    if (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === 'gawebtelemetry.com' ||
      hostname === 'www.gawebtelemetry.com' ||
      !hostname.includes('vercel.app')
    ) {
      return ''; // Nginx / Vite forwards /api and /socket.io
    }
  }

  // Fallback to production backend on Render (e.g. if hosted on external Vercel)
  return 'https://web-telemetry-backend.onrender.com';
};

export const BACKEND_URL = getBackendHost();
export const API_BASE = BACKEND_URL ? `${BACKEND_URL}/api` : '/api';
export const SOCKET_URL = BACKEND_URL || (typeof window !== 'undefined' ? window.location.origin : '');
