import React, { useState } from 'react';
import {
  Layers,
  ArrowRightLeft,
  Image as ImageIcon,
  MousePointerClick,
  Heading,
  Navigation,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  RefreshCw,
  SlidersHorizontal,
  FileDiff,
  ShieldCheck,
  Eye,
  Info,
  Check,
  AlertCircle,
  Layout,
  Monitor,
  Smartphone,
  ExternalLink
} from 'lucide-react';

export default function VisualIntegrityDashboard({ stats }) {
  const [activeSubTab, setActiveSubTab] = useState('diff'); // 'diff' | 'images' | 'elements' | 'raw'
  const [elementFilter, setElementFilter] = useState('all'); // 'all' | 'buttons' | 'headings' | 'navLinks'
  const [activeViewMode, setActiveViewMode] = useState('pictorial'); // 'pictorial' | 'details'

  const viData = stats?.latestStatus?.visualIntegrity || stats?.visualIntegrity || null;
  const lastSnapshot = viData?.lastSnapshot;
  const currentSnapshot = viData?.currentSnapshot;
  const stabilityScore = viData?.stabilityScore ?? 100;
  const status = viData?.status ?? 'stable';
  const hasBaseline = viData?.hasBaseline ?? false;
  const isSyntheticBaseline = viData?.isSyntheticBaseline ?? false;

  const imageChanges = viData?.imageChanges || { replaced: [], added: [], removed: [], unchangedCount: 0 };
  const elementChanges = viData?.elementChanges || { buttons: [], headings: [], navLinks: [] };
  const domDiff = viData?.domDiff || { imageDelta: 0, buttonDelta: 0, headingDelta: 0, bodyLengthDelta: 0 };

  const totalModifications = viData?.totalModifications ?? 
    (imageChanges.replaced.length + imageChanges.added.length + imageChanges.removed.length + 
     elementChanges.buttons.length + elementChanges.headings.length + elementChanges.navLinks.length);

  // Helper to render a visual wireframe browser mockup of a snapshot
  const renderPictorialMockup = (snap, isLive = false) => {
    const images = snap?.images || [];
    const headings = snap?.headings || [];
    const buttons = snap?.buttons || [];
    const navLinks = snap?.navLinks || [];

    const heroHeading = headings[0]?.text || 'Main Page Title';
    const subHeading = headings[1]?.text || headings[2]?.text || 'Sub-headline or key service introduction.';
    const ctaButton = buttons[0]?.text || 'Primary Call to Action';
    const secondaryBtn = buttons[1]?.text;
    const heroImage = images[0]?.src;

    return (
      <div className="w-full rounded-2xl overflow-hidden border border-slate-700/80 bg-slate-950 shadow-2xl transition-all">
        {/* Browser Top Chrome / Title Bar */}
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
          </div>
          <div className="px-4 py-0.5 rounded-md bg-slate-950 border border-slate-800/80 text-[10px] text-slate-400 font-mono flex items-center gap-1.5 truncate max-w-[260px]">
            <span className="text-emerald-400">https://</span>
            <span className="truncate">{stats?.url?.replace(/^https?:\/\//, '') || 'your-site.com'}</span>
          </div>
          <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
            isLive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
          }`}>
            {isLive ? 'LIVE STATE' : 'PAST STATE'}
          </span>
        </div>

        {/* Browser Viewport Simulation Canvas */}
        <div className="p-4 space-y-4 bg-gradient-to-b from-slate-950 to-slate-900 min-h-[380px] flex flex-col justify-between">
          
          {/* 1. Header Navigation Bar Mockup */}
          <div className="pb-3 border-b border-slate-800/80 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center font-black text-[11px] text-white">
                GA
              </div>
              <span className="text-xs font-bold text-white tracking-tight truncate max-w-[120px]">
                {stats?.siteName || 'Brand Logo'}
              </span>
            </div>

            {/* Nav Menu Links */}
            <div className="flex items-center gap-2 text-[10px] font-medium text-slate-400 overflow-x-hidden">
              {(navLinks.slice(0, 3)).map((n, i) => (
                <span key={i} className="px-2 py-1 rounded bg-slate-900/60 border border-slate-800/80 truncate max-w-[80px]">
                  {n.text}
                </span>
              ))}
              {navLinks.length === 0 && (
                <>
                  <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-500">Home</span>
                  <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-500">About</span>
                  <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-500">Contact</span>
                </>
              )}
            </div>
          </div>

          {/* 2. Hero Section Mockup (Title, Subhead, CTA Button, Hero Photo) */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center py-2">
            
            {/* Text & Action Column */}
            <div className="md:col-span-7 space-y-2.5">
              <div className="inline-block px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 text-[9px] font-bold text-indigo-400 uppercase tracking-wider">
                Hero Landmark
              </div>
              <h4 className="text-base font-black text-white leading-tight line-clamp-2">
                {heroHeading}
              </h4>
              <p className="text-[11px] text-slate-400 leading-snug line-clamp-2">
                {subHeading}
              </p>

              {/* Primary Call to Action Button */}
              <div className="pt-1 flex flex-wrap items-center gap-2">
                <div className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/30">
                  <MousePointerClick className="w-3 h-3" />
                  <span className="truncate max-w-[130px]">{ctaButton}</span>
                </div>
                {secondaryBtn && (
                  <div className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-medium text-xs truncate max-w-[120px]">
                    {secondaryBtn}
                  </div>
                )}
              </div>
            </div>

            {/* Photo Preview Column */}
            <div className="md:col-span-5">
              <div className="aspect-video w-full rounded-xl bg-slate-900 border border-slate-800 relative overflow-hidden flex items-center justify-center group">
                {heroImage ? (
                  <img
                    src={heroImage}
                    alt="Hero Asset"
                    className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition-opacity"
                    onError={(e) => { e.target.style.display = 'none'; }}
                  />
                ) : (
                  <div className="text-center p-3 text-slate-600 space-y-1">
                    <ImageIcon className="w-6 h-6 mx-auto opacity-40 text-indigo-400" />
                    <div className="text-[10px] font-bold uppercase tracking-wider">Image Asset</div>
                  </div>
                )}
                <div className="absolute bottom-1.5 right-1.5 px-2 py-0.5 rounded bg-slate-950/80 border border-slate-800 text-[9px] font-mono text-slate-300">
                  {snap?.domStats?.totalImages || 0} Assets
                </div>
              </div>
            </div>

          </div>

          {/* 3. Section Grid Cards (Sub-features / content cards) */}
          <div className="pt-3 border-t border-slate-800/80">
            <div className="text-[9px] font-bold uppercase tracking-wider text-slate-500 mb-2">
              Body Content Structure ({headings.length} Sections)
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(headings.slice(1, 4)).map((h, i) => (
                <div key={i} className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/80 space-y-1">
                  <div className="h-1.5 w-6 rounded bg-indigo-500/40"></div>
                  <div className="text-[10px] font-bold text-slate-200 truncate">{h.text}</div>
                  <div className="h-1 w-full rounded bg-slate-800"></div>
                  <div className="h-1 w-3/4 rounded bg-slate-800"></div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Bar */}
          <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-500">
            <span>Snapshot: {snap?.timestamp ? new Date(snap.timestamp).toLocaleTimeString() : 'Baseline'}</span>
            <span className="font-mono">{snap?.domStats?.totalHeadings || 0} Titles · {snap?.domStats?.totalButtons || 0} Buttons</span>
          </div>

        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      
      {/* 1. Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-indigo-950/30 border border-indigo-500/30 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3" /> Visual SRE Auditor
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border flex items-center gap-1.5 ${
                totalModifications === 0
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              }`}>
                {totalModifications === 0 ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : <AlertTriangle className="w-3.5 h-3.5" />}
                {totalModifications === 0 ? 'Everything Matched & Healthy' : `${totalModifications} UI Differences Spotted`}
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <Layers className="text-indigo-400 h-6 w-6" /> Pictorial UI Snapshot Comparison
            </h2>
            <p className="text-xs md:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Side-by-side pictorial mockup comparing your <strong>Past Snapshot</strong> against your <strong>Live Snapshot</strong> to see what moved, what was reworded, or which photos changed.
            </p>
          </div>

          {/* Quick Result Stat Badges */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="px-5 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center min-w-[120px]">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Layout Match</div>
              <div className={`text-2xl font-black ${
                stabilityScore >= 95 ? 'text-emerald-400' : stabilityScore >= 75 ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {stabilityScore}%
              </div>
              <div className="text-[9px] text-slate-500 font-semibold mt-0.5">
                {stabilityScore === 100 ? '100% Identical' : 'Changes Spotted'}
              </div>
            </div>

            <div className="px-5 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center min-w-[120px]">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Changes</div>
              <div className={`text-2xl font-black ${totalModifications > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {totalModifications}
              </div>
              <div className="text-[9px] text-slate-500 font-semibold mt-0.5">
                {totalModifications === 0 ? 'Zero Disturbances' : 'Review Differences'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Visual Mode Selector (Pictorial View vs. Detailed Breakdown) */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          {[
            { id: 'diff', label: '1. Visual Comparison', icon: Layout },
            { id: 'images', label: `2. Image Check (${imageChanges.replaced.length} replaced)`, icon: ImageIcon },
            { id: 'elements', label: `3. Buttons & Headings (${elementChanges.buttons.length + elementChanges.headings.length} changed)`, icon: MousePointerClick },
            { id: 'raw', label: '4. Summary Totals', icon: FileDiff }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveSubTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                activeSubTab === id
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 ring-2 ring-indigo-400/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {/* Toggle between Graphical Pictorial Mode vs Numbers List */}
        {activeSubTab === 'diff' && (
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveViewMode('pictorial')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
                activeViewMode === 'pictorial' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" /> Pictorial Mockup
            </button>
            <button
              onClick={() => setActiveViewMode('details')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
                activeViewMode === 'details' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileDiff className="w-3.5 h-3.5" /> Item Breakdown
            </button>
          </div>
        )}
      </div>

      {/* TAB 1: SIDE BY SIDE COMPARISON */}
      {activeSubTab === 'diff' && (
        <div className="space-y-6">

          {/* PICTORIAL REPRESENTATION (Graphic Browser Mockups) */}
          {activeViewMode === 'pictorial' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">
                  <strong>Pictorial Preview:</strong> Compare the visual layout, hero banner, titles, and CTA buttons from the previous scan side-by-side with the current live scan.
                </span>
                <span className="text-[11px] text-slate-500 font-mono hidden md:inline">
                  Interactive UI Simulation
                </span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Previous Snapshot Wireframe */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                      Previous State (Baseline)
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      {lastSnapshot?.timestamp ? new Date(lastSnapshot.timestamp).toLocaleTimeString() : 'Earlier'}
                    </span>
                  </div>
                  {renderPictorialMockup(lastSnapshot, false)}
                </div>

                {/* Latest Snapshot Wireframe */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      Live Current State (Now)
                    </span>
                    <span className="text-[11px] font-mono text-indigo-400/80">
                      {currentSnapshot?.timestamp ? new Date(currentSnapshot.timestamp).toLocaleTimeString() : 'Now'}
                    </span>
                  </div>
                  {renderPictorialMockup(currentSnapshot, true)}
                </div>

              </div>
            </div>
          )}

          {/* DETAIL LIST MODE (Numbered Breakdown Cards) */}
          {activeViewMode === 'details' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Left Card: PREVIOUS SNAPSHOT */}
              <div className="glass-card p-6 border border-slate-800 rounded-2xl bg-slate-900/60 relative">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                      <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
                        Previous Snapshot (Baseline)
                      </h3>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      How your website was configured in the previous scan
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-400">
                    {lastSnapshot?.timestamp ? new Date(lastSnapshot.timestamp).toLocaleTimeString() : 'Earlier'}
                  </span>
                </div>

                {/* Counts Grid */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Total Photos</div>
                    <div className="text-lg font-black text-slate-200 mt-0.5">{lastSnapshot?.domStats?.totalImages ?? 0}</div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Clickable Buttons</div>
                    <div className="text-lg font-black text-slate-200 mt-0.5">{lastSnapshot?.domStats?.totalButtons ?? 0}</div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Titles &amp; Headings</div>
                    <div className="text-lg font-black text-slate-200 mt-0.5">{lastSnapshot?.domStats?.totalHeadings ?? 0}</div>
                  </div>
                </div>

                {/* Headings */}
                <div className="mb-4">
                  <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5"><Heading className="w-3.5 h-3.5 text-slate-400" /> Page Titles / Headings:</span>
                  </div>
                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800/80 max-h-48 overflow-y-auto space-y-1.5 text-xs font-mono">
                    {(lastSnapshot?.headings || []).slice(0, 8).map((h, i) => (
                      <div key={i} className="text-slate-300 truncate py-0.5 flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400 font-bold uppercase shrink-0">
                          {h.level}
                        </span>
                        <span className="truncate">{h.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Buttons */}
                <div>
                  <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5"><MousePointerClick className="w-3.5 h-3.5 text-slate-400" /> Buttons &amp; Clickable Links:</span>
                  </div>
                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800/80 max-h-40 overflow-y-auto space-y-1.5 text-xs font-mono">
                    {(lastSnapshot?.buttons || []).slice(0, 8).map((b, i) => (
                      <div key={i} className="text-slate-300 truncate py-0.5 flex items-center gap-1.5">
                        <span className="text-indigo-400 font-bold">&rarr;</span>
                        <span className="truncate">{b.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Card: LATEST SNAPSHOT */}
              <div className="glass-card p-6 border border-indigo-500/40 rounded-2xl bg-indigo-950/15 relative">
                <div className="flex items-center justify-between pb-3 border-b border-indigo-500/20 mb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <h3 className="text-sm font-black uppercase tracking-wider text-indigo-200">
                        Latest Snapshot (Current State)
                      </h3>
                    </div>
                    <p className="text-[11px] text-indigo-300/80 mt-0.5">
                      Live scan taken right now
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-indigo-950 border border-indigo-500/30 text-[10px] font-mono text-indigo-300">
                    {currentSnapshot?.timestamp ? new Date(currentSnapshot.timestamp).toLocaleTimeString() : 'Live'}
                  </span>
                </div>

                {/* Counts Grid */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Total Photos</div>
                    <div className="text-lg font-black text-white mt-0.5 flex items-center justify-center gap-1">
                      {currentSnapshot?.domStats?.totalImages ?? 0}
                      {domDiff.imageDelta !== 0 && (
                        <span className={`text-[10px] ${domDiff.imageDelta > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          ({domDiff.imageDelta > 0 ? `+${domDiff.imageDelta}` : domDiff.imageDelta})
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Clickable Buttons</div>
                    <div className="text-lg font-black text-white mt-0.5 flex items-center justify-center gap-1">
                      {currentSnapshot?.domStats?.totalButtons ?? 0}
                      {domDiff.buttonDelta !== 0 && (
                        <span className={`text-[10px] ${domDiff.buttonDelta > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          ({domDiff.buttonDelta > 0 ? `+${domDiff.buttonDelta}` : domDiff.buttonDelta})
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Titles &amp; Headings</div>
                    <div className="text-lg font-black text-white mt-0.5 flex items-center justify-center gap-1">
                      {currentSnapshot?.domStats?.totalHeadings ?? 0}
                      {domDiff.headingDelta !== 0 && (
                        <span className={`text-[10px] ${domDiff.headingDelta > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          ({domDiff.headingDelta > 0 ? `+${domDiff.headingDelta}` : domDiff.headingDelta})
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Headings */}
                <div className="mb-4">
                  <div className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5"><Heading className="w-3.5 h-3.5 text-indigo-400" /> Page Titles / Headings:</span>
                  </div>
                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800/80 max-h-48 overflow-y-auto space-y-1.5 text-xs font-mono">
                    {(currentSnapshot?.headings || []).slice(0, 8).map((h, i) => (
                      <div key={i} className="text-slate-200 truncate py-0.5 flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-indigo-900/50 text-[10px] text-indigo-300 font-bold uppercase shrink-0 border border-indigo-500/20">
                          {h.level}
                        </span>
                        <span className="truncate">{h.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Buttons */}
                <div>
                  <div className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5"><MousePointerClick className="w-3.5 h-3.5 text-indigo-400" /> Buttons &amp; Clickable Links:</span>
                  </div>
                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800/80 max-h-40 overflow-y-auto space-y-1.5 text-xs font-mono">
                    {(currentSnapshot?.buttons || []).slice(0, 8).map((b, i) => (
                      <div key={i} className="text-slate-200 truncate py-0.5 flex items-center gap-1.5">
                        <span className="text-emerald-400 font-bold">&rarr;</span>
                        <span className="truncate">{b.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* TAB 2: IMAGE REPLACEMENT TRACKER */}
      {activeSubTab === 'images' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
            <strong>What this checks:</strong> Checks whether any photo, logo, or banner on your website was swapped, deleted, or replaced with a new file.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Replaced Images</div>
              <div className="text-2xl font-black text-amber-400 mt-1">{imageChanges.replaced.length}</div>
              <p className="text-[11px] text-slate-400 mt-1">Photo changed to a different image file</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">New Images Added</div>
              <div className="text-2xl font-black text-emerald-400 mt-1">{imageChanges.added.length}</div>
              <p className="text-[11px] text-slate-400 mt-1">New photos published since last scan</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Removed / Deleted</div>
              <div className="text-2xl font-black text-rose-400 mt-1">{imageChanges.removed.length}</div>
              <p className="text-[11px] text-slate-400 mt-1">Photos deleted or missing</p>
            </div>
          </div>

          {imageChanges.replaced.length > 0 ? (
            <div className="glass-card p-5 border border-amber-500/30 rounded-2xl bg-amber-500/5 space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Detected Image Replacements
              </h4>
              {imageChanges.replaced.map((rep, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="font-bold text-slate-300 flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] uppercase font-bold">REPLACED</span>
                    {rep.alt || 'Website Image'}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
                    <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-300 truncate">
                      <span className="text-slate-400 font-sans font-bold block uppercase text-[9px] mb-1">Old Image:</span>
                      {rep.oldSrc}
                    </div>
                    <div className="p-2.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 truncate">
                      <span className="text-slate-400 font-sans font-bold block uppercase text-[9px] mb-1">New Image:</span>
                      {rep.newSrc}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center text-xs text-slate-400 space-y-1">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <div className="font-bold text-slate-200">No Image Replacements</div>
              <div>All image assets and photos match the baseline snapshot without any unauthorized changes.</div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: DISTURBED UI ELEMENTS */}
      {activeSubTab === 'elements' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
            <strong>What this checks:</strong> Detects if any heading title was reworded, or if a "Buy Now", "Contact Us", or "Sign Up" button was altered or deleted.
          </div>

          <div className="glass-card p-5 border border-slate-800 rounded-2xl bg-slate-900/60">
            {elementChanges.buttons.length === 0 && elementChanges.headings.length === 0 && elementChanges.navLinks.length === 0 ? (
              <div className="py-10 text-center text-xs text-slate-400 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="font-bold text-slate-200">All Buttons &amp; Headings are Stable</div>
                <div>No deleted or disturbed buttons, reworded titles, or missing menu links between scans.</div>
              </div>
            ) : (
              <div className="space-y-2.5">
                {elementChanges.buttons.map((b, i) => (
                  <div key={`btn_${i}`} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <MousePointerClick className="w-4 h-4 text-indigo-400 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Button</span>
                        <span className="font-mono text-slate-200">{b.item}</span>
                      </div>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      b.type === 'added' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      {b.type}
                    </span>
                  </div>
                ))}
                {elementChanges.headings.map((h, i) => (
                  <div key={`h_${i}`} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <Heading className="w-4 h-4 text-indigo-400 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Heading</span>
                        <span className="font-mono text-slate-200">{h.item}</span>
                      </div>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      h.type === 'added' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      {h.type}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: SUMMARY TOTALS */}
      {activeSubTab === 'raw' && (
        <div className="glass-card p-6 border border-slate-800 rounded-2xl bg-slate-900/60 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200">
            Total Elements Comparison
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] font-bold uppercase text-slate-400">Photos Difference</div>
              <div className="text-xl font-black text-white mt-1">
                {domDiff.imageDelta === 0 ? '0 (Unchanged)' : (domDiff.imageDelta > 0 ? `+${domDiff.imageDelta}` : domDiff.imageDelta)}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] font-bold uppercase text-slate-400">Buttons Difference</div>
              <div className="text-xl font-black text-white mt-1">
                {domDiff.buttonDelta === 0 ? '0 (Unchanged)' : (domDiff.buttonDelta > 0 ? `+${domDiff.buttonDelta}` : domDiff.buttonDelta)}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] font-bold uppercase text-slate-400">Titles Difference</div>
              <div className="text-xl font-black text-white mt-1">
                {domDiff.headingDelta === 0 ? '0 (Unchanged)' : (domDiff.headingDelta > 0 ? `+${domDiff.headingDelta}` : domDiff.headingDelta)}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] font-bold uppercase text-slate-400">Page Text Shift</div>
              <div className="text-xl font-black text-white mt-1">
                {domDiff.bodyLengthDelta === 0 ? '0 chars' : `${domDiff.bodyLengthDelta > 0 ? `+${domDiff.bodyLengthDelta}` : domDiff.bodyLengthDelta} chars`}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
